def lambda_handler(event, context):
    path = parse(event, "resource")
    http_method = event["httpMethod"]
    return {
        'isBase64Encoded': False,
        'statusCode': 200,

    }


def parse(content, key):
    return content[key]